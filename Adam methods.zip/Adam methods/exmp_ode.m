function fValue = exmp_ode(x, y)
% the ODE dy/dx = -y - 3 * x
fValue = -y - 3 * x;
end 